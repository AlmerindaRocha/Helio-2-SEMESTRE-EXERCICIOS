/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    double a,d,resultado;
    char b;
    printf("Digite um valor ");
    scanf("%lf", &a);
    printf("Digite o segundo");
    scanf("%lf", &d);
    
    printf("Digite seu operando +,-,*,/ ");
    scanf(" %c", &b); // Note o espaço antes de %c
     switch (b){
        case '+':
            resultado = a + d;
            printf("O resultado da operação é: %.2lf\n", resultado);

            break;
        case '-':
            resultado = a - d;
            printf("O resultado da operação é: %.2lf\n", resultado);

            break;
        case '*':
            resultado = a * d;
            printf("O resultado da operação é: %.2lf\n", resultado);

            break;
        case '/':
            if (d != 0) {
                resultado = a / d;
                printf("O resultado da operação é: %.2lf\n", resultado);}
              
             else {
                printf("Erro! Divisão por zero.\n");}
                  break;
            
            return 0;

}
}

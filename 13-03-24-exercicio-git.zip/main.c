/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/



int main(void)
{   const double d=10;
    const double c=100;
    const double m=1000;
    double a,b,pd,pc,pm;
    printf("digite o valor em metros");
    scanf("%lf",&a);
    printf("1 para decímetro  2 para centímetro e 3 para milímetro");
    scanf("%lf",&b);
     if(b==1)
    {
        pd=a*d;
        printf("O valor em decimetro é  %.2lf\n",pd );
    }
    else if(b==2)
    {     pc=a*c;

         printf("O valor em centímetro é  %.2lf\n",pc );
    }
    else if(b==3)
    {
         pm=a*m;
     printf("O valor em milímetro é : %.2lf\n",pm );
        
    }
}

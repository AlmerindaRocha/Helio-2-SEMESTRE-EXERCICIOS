/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


int main(void )
{
    double a, b;
    printf("Digite o primeiro valor  ");
    scanf("%lf", &a);
    printf("Digite o segundo valor  ");
    scanf("%lf", &b);
    if(a<b)
    {  printf("A ordem é %.2lf e %.2lf\n", a, b);}
     if(a>b)
    {  printf("A ordem é %.2lf e %.2lf\n", b, a);}
     if(a==b)
    {  printf("valores iguais  %.2lf = %.2lf\n", b, a);}
}

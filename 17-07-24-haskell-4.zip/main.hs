potencia::(Integral b,Fractional a) => a->b->a
potencia a b 
  |b ==0 =1
  |b >0  =a* potencia a (b-1)
  |b <0  =1 / potencia a(-b)
  
main ::IO()
main = do 
     putStrLn "Digite a base "
     baseInput <- getLine
     let base= read baseInput :: Double
     
     putStrLn "Digite o expoente "
     expoenteInput <- getLine
     let expoente = read expoenteInput :: Int
     
     let resultado = potencia base expoente
     
     putStrLn("O resultadode " ++show base++ "elevado a " ++show expoente ++ "é " ++show resultado)
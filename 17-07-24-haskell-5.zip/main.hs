torreHanoi :: Int->String->String->String->IO()
torreHanoi 0 _ _ _ = return ()
torreHanoi n origem destino trabalho = do 
     torreHanoi(n-1)origem trabalho destino
     putStrLn("Mover disco do pino "++origem++ "para o pino "++destino)
     torreHanoi(n-1)trabalho destino origem 
     
main:: IO()
main=do 
      putStrLn "Digite o número de discos "
      input<- getLine
      let numDiscos = read input :: Int
      torreHanoi numDiscos "A" "C" "B"

mdc :: Int->Int->Int
mdc a 0 = a 
mdc a b = mdc b (a `mod` b)

main::IO()
main = do 

  putStrLn "primeiro numero = "
  a <- readLn
  putStrLn "segundo numero = "
  b <- readLn 
  putStrLn("MDC = " ++show(mdc a b ))
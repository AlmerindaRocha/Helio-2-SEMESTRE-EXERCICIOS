main :: IO()

verifica:: String->String->String->IO()
verifica nome sexo estadoCivil = do 
    if sexo  == "F" && estadoCivil == "CASADA" 
    then do
    putStrLn "Digite o tempo de casada " 
    tempoCasada <- getLine 
    putStrLn$"Nome :" ++nome 
    putStrLn$"Sexo :" ++sexo 
    putStrLn$"Estado civil " ++estadoCivil 
    putStrLn$"Tempo de casada" +tempoCasada ++"anos"
    else do 
    putStrLn$ "Nome :" ++nome 
    putStrLn$ "Sexo :" ++sexo 
    putStrLn$ "Estado civil " ++estadoCivil 
    
--IO VAI SER USADO NO FINAL QUANDO NAO TEM FUNCAO MAIN 
-- DO E PARA EXECUTAR AS LINHAS DE CODIGO 
--$ e usado para concatenar corretamente 

main = do 
      putStrLn "Digite seu nome :" 
      nome <- getLine 
      putStrLn "Digite o sexo (M/F)"  
      sexo <- getLine 
      putStrLn "Digite o estado civil " 
      estadoCivil <-getLine 
      
      verifica nome sexo estadoCivil 
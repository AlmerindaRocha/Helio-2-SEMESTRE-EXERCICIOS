main :: IO ()
triangulo :: Float -> Float
triangulo t   = (1.7320508075688772 * (t * t)) / 4

main = do
    putStrLn "Digite um lado: "
    t <- readLn
    putStrLn ("O valor é = " ++ show (triangulo t))

